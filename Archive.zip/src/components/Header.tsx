import Link from 'next/link';

interface HeaderProps {
  accentColor?: 'pink' | 'indigo';
}

export default function Header({ accentColor = 'pink' }: HeaderProps) {
  const dotColor = accentColor === 'indigo' ? 'text-indigo-500' : 'text-pink-500';

  return (
    <header className="w-full px-8 py-6 md:px-12 md:py-8 flex items-center justify-between z-30 bg-slate-900 border-b border-slate-800">
      <Link href="/" className="text-2xl font-extrabold tracking-tighter text-white">
        ROLEMATCH<span className={dotColor}>.</span>
      </Link>
      
      <div className="flex items-center gap-6">
        <Link href="/jobs" className="text-sm font-bold text-slate-300 hover:text-white transition">
          Jobs
        </Link>
        <Link href="/login" className="text-sm font-bold text-slate-300 hover:text-white transition">
          Login
        </Link>
        <Link href="/register" className="px-5 py-2.5 rounded-full bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-wider transition shadow-md">
          Register
        </Link>
      </div>
    </header>
  );
}